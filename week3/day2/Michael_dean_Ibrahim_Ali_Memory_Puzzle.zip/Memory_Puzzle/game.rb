
class Game
attr_reader :player, 
    def initialize(player, n)
        @player = player
        @board = Board.new(n) 
        @previous_guess = []
        @current_guess = []
    end

    

    # methods for managing the Board-Player interaction


    def play
        @current_guess = []
        until input 
            puts 'pick first card'
            @board.render
            input = gets.chomp        
            input = input.split(" ").map(&:to_i)
            if !is_valid?(input)
                puts "INAVLID INPUT"
                input = nil
            end
        @current_guess << input
        end
        until input2
            puts 'pick second card'
            @board.render
            input2 = gets.chomp        
            input2 = input2.split(" ").map(&:to_i)
            if !is_valid?(input2) && input != input2
                puts "INAVLID INPUT"
                input2 = nil
            end
        @current_guess << input2
        if @board[@current_guess[0]] == @board[@current_guess[1]]
            @previous_guess += @current_guess
            @current_guess[0].reveal
            @current_guess[1].reveal
        else
            @current_guess[0].hide
            @current_guess[1].hide
        end
        end
    end



# 0, 2
    def is_valid?(pos)
        row, col = pos
        return false if (row < 0 || row > @board.size) || (col < 0 || col > @board.size)
        return false if @previous_guess.include?(pos)
        true
    end
    





end