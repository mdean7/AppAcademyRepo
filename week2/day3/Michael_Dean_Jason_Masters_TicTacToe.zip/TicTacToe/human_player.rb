class Human_player
    
end